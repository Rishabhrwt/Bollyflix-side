function openSearch() {
  document.getElementById("myOverlay").style.display = "block";
}

function closeSearch() {
  document.getElementById("myOverlay").style.display = "none";
}

function openNav() {
  document.getElementById("mySidepanel").style.width = "300px";
  document.body.style.overflow = "hidden";
  document.getElementById("backdrop").style.display = "block";
  document.getElementById("mySidepanel").style.backgroundColor = "white";
  document.getElementById("mySidepanel").style.transition = "0.3s ease";
}

function closeNav() {
  document.getElementById("mySidepanel").style.width = "0";
  document.body.style.overflow = "auto";
  document.getElementById("backdrop").style.display = "none";
  document.getElementById("mySidepanel").style.backgroundColor = "rgba(0, 0, 0, 0)";
  document.getElementById("mySidepanel").style.transition = "0.5s ease";
}

//HEader js//

const header = document.querySelector('header');
const headerFixed = () => {
  if (window.innerWidth <= 1440 && window.scrollY > 50) {
    header.style.position = 'fixed';
    header.style.top = '-80px';
    header.style.left = '0px';
    header.style.zIndex = 100000000000000;
    header.style.width = '100%';
    header.style.background = white;

    if (window.scrollY > 50) {
      header.style.top = '0';
    }
  } else {
    header.style.position = 'relative';
    header.style.top = 'inherit';
  }
}

window.addEventListener('scroll', headerFixed);
